<?php
    // Configuración de la base de datos en un array que se incluirá en las funciones de bd.php
    $bd_config = ["ip" => "127.0.0.1",
                 "nombrebd" => "pmp",
                 "usuario" => "root",
                 "clave" => ""];
